function TestBuilder () {
    if (!TestBuilder.Test) TestBuilder.Test = this;
    return TestBuilder.Test;
}

TestBuilder.create = function () {
    var test = TestBuilder.Test;
    var ret = new TestBuilder();
    TestBuilder.Test = test;
    ret.reset();
    return ret;
}

TestBuilder.prototype.reset = function () {
    this.TestDied      = false;
    this.HavePlan      = false;
    this.NoPlan        = false;
    this.CurrTest      = 0;
    this.Level         = 1;
    this.ExpectedTests = 0;
    this.SkipAll       = false;
    this.UseNums       = true;
    this.NoHeader      = false;
    this.NoEnding      = false;
    this.TestResults   = [];
    // XXX We need to figure out where output goes. Duping the methods should
    // be easy, though.
    // this._dup_stdhandles;
}

TestBuilder.prototype.reset();
TestBuilder.Test = TestBuilder.prototype;

TestBuilder._print = function (msg) {
    // XXX What if there is no document?
    document.write(msg);
}

TestBuilder.prototype._print = TestBuilder._print;

TestBuilder.die = function (msg) {
    // XXX How do I throw errors in versions of JS without exceptions?
    // XXX This error would ideally have the file name and line number of
    // the calling code.
    throw new Error(msg);
}

TestBuilder.warn = function (msg) {
    // XXX What if there is no global alert method?
    // XXX I'd love to get file name and line numbers here.
    alert(msg);
}

TestBuilder.prototype.plan = function (cmd, arg) {
    if (!cmd) return;
    if (this.HavePlan) TestBuilder.die("You tried to plan twice!");

    if (cmd == 'no_plan') {
        this.noPlan();
    } else if (cmd == 'skip_all') {
        return this.skipAll(arg);
    } else if (cmd == 'tests') {
        if (arg) {
            return this.expectedTests(arg);
        } else if (arg == null) {
            TestBulder.die(
                "Got an undefined number of tests. Looks like you tried to "
                + "say how many tests you plan to run but made a mistake.\n"
            );
        } else if (!arg) {
            TestBuilder.die(
                "You said to run 0 tests! You've got to run something.\n"
            );
        }
    } else {
        TestBuilder.die("plan() doesn't understand " + arguments);
    }
}

TestBuilder.prototype.expectedTests = function (max) {
    if (max) {
        if (isNaN(max)) {
            TestBuilder.die(
                "Number of tests must be a postive integer. You gave it '"
                + max + "'.\n"
            );
        }

        this.ExpectedTests = max.valueOf();
        this.HavePlan       = 1;
        if (!this.noHeader()) TestBuilder._print("1.." + max + "\n");
    }
    return this.ExpectedTests;
}

TestBuilder.prototype.noPlan = function () {
    this.NoPlan   = 1;
    this.HavePlan = 1;
}

TestBuilder.prototype.hasPlan = function () {
    if (this.ExpectedTests) return this.ExpectedTests;
    if (this.NoPlan) return 'no_plan';
}

TestBuilder.prototype.skipAll = function (reason) {
    var out = "1..0";
    if (reason) out += " # Skip " + reason;
    out += "\n";
    this.SkipAll = 1;
    if (!this.noHeader()) this._print(out);
    // XXX How does one exit JavaScript?
    // exit(0);
}

TestBuilder.prototype.ok = function (test, desc) {
    // test might contain an object that we don't want to accidentally
    // store, so we turn it into a boolean.
    test = !!test;

    if (!this.HavePlan)
        TestBuilder.die("You tried to run a test without a plan! Gotta have a plan.");

    // XXX Do we need to worry about threading in JavaScript?
    this.CurrTest++;

    // In case desc is a string overloaded object, force it to stringify.
    if (desc) desc = desc.toString();

    var startsNumber
    if (desc != null && /^[\d\s]+$/.test(desc)) {
        this.diag( "Your test description is '" + desc + "'. You shouldn't use\n",
                   "numbers for your test names. Very confusing.");
    }

    var caller = this.caller();
    var todo = this.todo(caller.pack);
    var out = '';
    // XXX Do we need to worry about result beeing shared between threads?
    var result = [];

    if (test) {
        result['ok']        = todo ? true : false;
        result['actual_ok'] = false;
    } else {
        out += 'not ';
        result['ok']        = true;
        result['actual_ok'] = test;
    }

    out += 'ok';
    if (this.useNumbers) out += ' ' + this.CurrTest;

    if (desc == null) {
        result['desc'] = '';
    } else {
        desc.split('#').join('\\#'); // # # in a desc can confuse TestHarness.
        out += ' - ' + desc;
        result['desc'] = desc;
    }

    if (todo) {
        out   += " # TODO $todo";
        result['reason'] = todo;
        result['type']   = 'todo';
    }
    else {
        result['reason'] = '';
        result['type']   = '';
    }

    this.TestResults[this.CurrTest - 1] = result;

    out += "\n";
    this._print(out);

    if (!test) {
        var msg = todo ? "Failed (TODO)" : "Failed";
        // XXX Hrm, do I need this?
        //$self_print_diag("\n") if $ENV{HARNESS_ACTIVE};
        this.diag("    " + msg + " test (" + caller.file + "at line "
                  + caller.line + ")\n");
    }

    return test;
}

TestBuilder.prototype.isEq = function (got, expect, desc) {
    // XXX What to do about levels?
    //local $Level = $Level + 1;
    if (got == null || expect == null) {
        // undefined only matches undefined and nothing else
        return this.isUndef(got, 'eq', expect, desc);
    }
    
    return this.cmpOk(got, 'eq', expect, desc);
}

TestBuilder.prototype.isNum = function (got, expect, desc) {
    // XXX What to do about levels?
    //local $Level = $Level + 1;

    if (got == null || expect == null) {
        // undefined only matches undefined and nothing else
        return this.isUndef(got, '==', expect, desc);
    }
    return this.cmpOk(got, '==', expect, desc);
}

TestBuilder.prototype.isntEq = function (got, dontExpect, desc) {
    // XXX What to do about levels?
    //local $Level = $Level + 1;
    if (got == null || dontExpect == null) {
        // undefined only matches undefined and nothing else
        return this.isUndef(got, 'ne', dontExpect, desc);
    }
    
    return this.cmpOk(got, 'ne', dontExpect, desc);
}

TestBuilder.prototype.isntNum = function (got, dontExpect, desc) {
    // XXX What to do about levels?
    //local $Level = $Level + 1;

    if (got == null || dontExpect == null) {
        // undefined only matches undefined and nothing else
        return this.isUndef(got, '!=', dontExpect, desc);
    }
    return this.cmpOk(got, '!=', dontExpect, desc);
}

TestBuilder.prototype.like = function (val, regex, desc) {
    // XXX What to do about levels?
    //local $Level = $Level + 1;
    return this._regexOk(val, regex, '=~', desc);
}

TestBuilder.prototype.unlike = function (val, regex, desc) {
    // XXX What to do about levels?
    //local $Level = $Level + 1;
    return this._regexOk(val, regex, '!~', desc);
}

TestBuilder.prototype._regexOk = function (val, regex, cmp, desc) {
    // XXX What to do about levels?
    //local $Level = $Level + 1;

    // Create a regex object.
    var type = TestBuilder.typeOf(regex);
    var ok;
    if (type.toLowerCase() == 'string') {
        // Create a regex object.
        regex = new RegExp(regex);
    } else {
        if (type != 'RegExp') {
            ok = this.ok(false, desc);
            this.diag("'" + regex + "' doesn't look much like a regex to me.");
            return ok;
        }
    }

    if (val == null) {
        if (cmp == '=~') {
            // The test fails.
            ok = this.ok(false, desc);
            this._diagLike(val, regex, cmp);
        } else {
            // undefined matches nothing (unlike in Perl, where undef =~ //).
            ok = this.ok(true, desc);
        }
        return ok;
    }

    // Use val.match() instead of regex.test() in case they've set g.
    var test = val.match(regex);
    if (cmp == '!~') test = !test;
    ok = this.ok(test, desc);
    if (!ok) this._diagLike(val, regex, cmp);
    return ok;
}

TestBuilder.prototype._diagLike = function (val, regex, cmp) {
    var match = cmp == '=~' ? "doesn't match" : "      matches";
    return this.diag(
        "                  '" + val + "'\n" +
        "    " + match + " /" + regex.source + "/"
    );
}

TestBuilder.StringOps = {
    eq: '==',
    ne: '!=',
    lt: '<',
    gt: '>',
    ge: '>=',
    le: '<=',
};

TestBuilder.prototype.cmpOk = function (got, op, expect, desc) {

    var test;
    if (TestBuilder.StringOps[op]) {
        // Force string context.
        test = eval("got.toString() " + TestBuilder.StringOps[op] + " expect.toString()");
    } else {
        test = eval("got " + op + " expect");
    }

    // XXX What to do about levels?
    //local $Level = $Level + 1;
    var ok = this.ok(test, desc);
    if (!ok) {
        if (/^(eq|==)$/.test(op)) {
            this._isDiag(got, op, expect);
        } else {
            this._cmpDiag(got, op, expect);
        }
    }
    return ok;
}

TestBuilder.prototype._cmpDiag = function (got, op, expect) {
    if (got != null) got = "'" + got.toString() + "'";
    if (expect != null) expect = "'" + expect.toString() + "'";
    return this.diag("    " + got + "\n        " + op + "\n    " + expect);
}

TestBuilder.prototype._isDiag = function (got, op, expect) {
    var args = [got, expect];
    for (var i in args) {
        if (args[i] != null) {
            args[i] = op == 'eq' ? "'" + args[i].toString() + "'" : args[i].valueOf();
        }
    }

    return this.diag(
        "         got: " + args[0] + "\n" +
        "    expected: " + args[1] + "\n"
    );
}

TestBuilder.prototype.BAILOUT = function (reason) {
    this._print("Bail out! " + reason);
    /// XXX How can we exit??
    //exit 255;
}

TestBuilder.prototype.skip = function (why) {
    if (!this.HavePlan)
        TestBuilder.die("You tried to run a test without a plan! Gotta have a plan.");

    // In case desc is a string overloaded object, force it to stringify.
    if (why) why = why.toString();

    this.CurrTest++;
    this.TestResults[this.CurrTest - 1] = {
        ok:        true,
        actual_ok: true,
        desc:      '',
        type:      'skip',
        reason:    why,
    };

    var out = "ok";
    if (this.useNumbers) out += ' ' + this.CurrTest;
    out    += " # skip " + why + "\n";
    this._print(out);
    return true;
}

TestBuilder.prototype.todoSkip = function (why) {
    if (!this.HavePlan)
        TestBuilder.die("You tried to run a test without a plan! Gotta have a plan.");

    // In case desc is a string overloaded object, force it to stringify.
    if (why) why = why.toString();

    this.CurrTest++;
    this.TestResults[this.CurrTest - 1] = {
        ok:        true,
        actual_ok: false,
        desc:      '',
        type:      'todo_skip',
        reason:    why,
    };

    var out = "not ok";
    if (this.useNumbers) out += ' ' + this.CurrTest;
    out    += " # TODO & SKIP " + why + "\n";
    this._print(out);
    return true;
}

TestBuilder.prototype.level = function (level) {
    if (!level == null) this.Level = level;
    return TestBuilder.Level;
}

TestBuilder.prototype.useNumbers = function (useNums) {
    if (!useNums == null) this.UseNums = useNums;
    return this.UseNums;
}

TestBuilder.prototype.noHeader = function (noHeader) {
    if (!noHeader == null) this.NoHeader = noHeader;
    return this.NoHeader;
}

TestBuilder.prototype.noEnding = function (noEnding) {
    if (!noEnding == null) this.NoEnding = noEnding;
    return this.NoEnding;
}

TestBuilder.prototype.diag = function () {
    if (!arguments.length) return;

    var msg = '# ';
    // Join each agument and escape each line with a #.
    // for (var i in arguments) doesn't work! Weird.
    for (i = 0; i < arguments.length; i++) {
        // Replace any newlines followed by a character.
        msg += arguments[i].replace(/\n(.)/g, "\n# $1");
    }

    // Append a new line to the end of the message if there isn't one.
    if (!/\n$/.test(msg)) msg += "\n";

    // XXX What do I do about this?
    // local $Level = $Level + 1;
    this._printDiag(msg);
}

TestBuilder.prototype._printDiag = function (msg) {
    // What if there is no document?
    document.write(msg);
    return false;
}

TestBuilder.prototype.currentTest = function (num) {
    if (num == null) return this.CurrTest;

    if (!this.HavePlan)
        TestBuilder.die("Can't change the current test number without a plan!");

    this.CurrTest = num;
    if (num > this.TestResults.length ) {
        for (i = this.TestResults.length; i < num; i++) {
            this.TestResults[i] = {
                ok:        true, 
                actual_ok: null,
                reason:    'incrementing test number', 
                type:      'unknown', 
                name:      null
            };
        }
    }
    return this.CurrTest;
}

TestBuilder.prototype.summary = function () {
    var results = [this.TestResults.length];
    for (var i in this.TestResults) {
        results[i] = this.TestResults[i]['ok'];
    }
    return results
}

TestBuilder.prototype.details = function () {
    return this.TestResults;
}

TestBuilder.prototype.todo = function (pack) {
    // XXX How to we handle ToDos?
    return false;
}

TestBuilder.prototype.caller = function () {
    // XXX How do we get at the package, file, and line information?
    // Is package even relevant anymore?
    return {
        pack: 0,
        file: '',
        line: 0,
    }
}

TestBuilder.prototype._sanity_check = function () {
    TestBuilder._whoa(
        this.CurrTest < 0,
        'Says here you ran a negative number of tests!'
    );

    TestBuilder._whoa(
        !this.HavePlan && this.CurrTest, 
        'Somehow your tests ran without a plan!'
    );

    TestBuilder._whoa(
        this.CurrTest != this.TestResults.length,
        'Somehow you got a different number of results than tests ran!'
    );
}

TestBuilder._whoa = function (check, desc) {
    if (!check) return;
    TestBuilder.die("WHOA! " + desc + "\nThis should never happen! "
                    + "Please contact the author immediately!");
}

TestBuilder.prototype._ending = function () {
    this._sanity_check();

    // Don't bother with an ending if this is a forked copy. Only the parent
    // should do the ending.
    // XXX Do we need to worry about threads?
    //do{ _my_exit($?) && return } if $Original_Pid != $$;

    // Bailout if plan() was never called.  This is so
    // "require Test::Simple" doesn't puke.
    // XXX I don't think this appplies.
    //do{ _my_exit(0) && return } if !$Have_Plan && !$Test_Died;

    // Figure out if we passed or failed and print helpful messages.
    if( this.TestResults.length ) {
        // The plan?  We have no plan.
        if (this.NoPlan) {
            if (!this.noHeader())
                this._print("1.." + this.CurrTest + "\n");
            this.ExpectedTests = this.CurrTest;
        }

        // Auto-extended arrays and elements that aren't explicitly
        // filled in with a shared reference will puke under 5.8.0
        // ithreads.  So we have to fill them in by hand. :(
        // XXX Again, I don't think this applies to JS.
        //my $empty_result = &share({});
        //for my $idx ( 0..$Expected_Tests-1 ) {
        //    $Test_Results[$idx] = $empty_result
        //    unless defined $Test_Results[$idx];
        //}

        var numFailed = 0;
        for (var i in this.TestResults) {
            if (!this.TestResults[i]) numFailed++;
        }
        numFailed += Math.abs(
            this.ExpectedTests - this.TestResults.length
        );

        if (this.CurrTest < this.ExpectedTests) {
            var s = this.ExpectedTests == 1 ? '' : 's';
            this.diag(
                "Looks like you planned " + this.ExpectedTests + " test"
                + s + " but only ran " + this.CurrTest + ".\n"
            );
        } else if (this.CurrTest > this.ExpectedTests) {
           var numExtra = this.CurrTest - this.ExpectedTests;
            var s = this.ExpectedTests == 1 ? '' : 's';
            this.diag(
                "Looks like you planned " + this.ExpectedTests + " test"
                + s + " but ran " + numExtra + " extra.\n"
            );
        } else if (numFailed) {
            var s = numFailed == 1 ? '' : 's';
            this.diag(
                "Looks like you failed " + numFailed + "test" + s + " of "
                + this.ExpectedTests + ".\n"
            );
        }

        if (this.TestDied) {
            this.diag(
                "Looks like your test died just after " 
                + this.CurrTest + ".\n"
            );
            // XXX exit?
            //_my_exit( 255 ) && return;
        }

        // XXX exit?
        //_my_exit( $num_failed <= 254 ? $num_failed : 254  ) && return;
    } else if (this.SkipAll ) {
        // XXX exit?
        //_my_exit( 0 ) && return;
    } else if (this.TestDied) {
        this.diag(
            "Looks like your test died before it could output anything.\n"
        );
        // XXX exit?
        //_my_exit( 255 ) && return;
    } else {
        this.diag("No tests run!\n");
        // XXX exit?
        //_my_exit( 255 ) && return;
    }
}

TestBuilder.typeOf = function (object) {
    var c = Object.prototype.toString.apply(object);
    var name = c.substring(8, c.length - 1);
    if (name != 'Object') return name;
    // It may be a non-core class. Try to extract the class name from
    // the constructor function. This may not work in all implementations.
    if (/function (.[^(]*)/.test(Function.toString.call(object.constructor))) {
        return RegExp.$1;
    }
    // No idea. :-(
    return name;
}

TestBuilder.prototype.isUndef = function (got, op, expect, desc) {
    // Undefined only matches undefined, so we don't need to cast anything.
    var test = eval("got " + (TestBuilder.StringOps[op] || op) + " expect");
    this.ok(test, desc);
    if (!test) this._isDiag(got, op, expect);
    return test;
}

