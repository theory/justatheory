// Create a namespace for ourselves. This constructor should never actually
// be called (XXX Should we make it _TestMore, perhaps?).
function TestMore () {}
TestMore.ShowDiag = true;
TestBuilder.DNE = { dne: 'Does not exist' };
TestMore.Test = new TestBuilder();

function plan () {
    var idx = 0;
    var cleaned_plan = [];
    for (i = 0; i < arguments.length; i++) {
        var item = arguments[i];
        if (item == 'no_diag') TestMore.ShowDiag = false;
        else cleaned_plan.push(item);
    }
    return TestMore.Test.plan.apply(TestMore.Test, cleaned_plan);
}

function ok (test, desc) {
    return TestMore.Test.ok(test, desc);
}

function is (got, expect, desc) {
    return TestMore.Test.isEq(got, expect, desc);
}

function isnt (got, expect, desc) {
    return TestMore.Test.isntEq(got, expect, desc);
}

function like (val, regex, desc) {
    return TestMore.Test.like(val, regex, desc);
}

function unlike (val, regex, desc) {
    return TestMore.Test.unlike(val, regex, desc);
}

function cmpOk(got, op, expect, desc) {
    return TestMore.Test.cmpOk(got, op, expect, desc);
}

function canOk (proto) {
    var ok;
    // Make sure they passed some method names for us to check.
    if (!arguments.length > 1) {
        ok = TestMore.Test.ok(false, clas + '.can(...)');
        TestMore.Test.diag('    canOk() called with no methods');
        return ok;
    }

    // Get the class name and the prototype.
    var clas;
    if (typeof proto == 'string') {
        // We just have a class name.
        clas = proto;
        proto = eval(clas + '.prototype');
    } else {
        // We have an object or something that can be converted to an object.
        clas = TestBuilder.typeOf(proto);
        proto = proto.constructor.prototype;
    }

    var nok = [];
    for (var i = 1; i < arguments.length; i++) {
        var method = arguments[i];
        if (typeof proto[method] != 'function') nok.push(method);
    }

    // There'es no can() method in JavaScript, but what the hell!
    var desc = clas + ".can('" + (arguments.length == 2 ? arguments[1] : '...') + "')";
    ok = TestMore.Test.ok(!nok.length, desc);
    for (var i in nok) {
        TestMore.Test.diag('    ' + clas + ".can('" + nok[i] + "') failed\n");
    }
    return ok;
}

function isaOk (object, clas, objName) {
    var mesg;
    if (objName == null) objName = 'The object';
    var name = objName + ' isa ' + clas;
    if (object == null) {
        mesg = objName + " isn't defined";
    } else if (!isRef(object)) {
        mesg = objName + " isn't a reference";
    } else {
        if (Object.isPrototypeOf) {
            // With JavaScript 1.5, we can determine inheritance.
            var ctor = eval(clas);
            if (!ctor.prototype.isPrototypeOf(object)) {
                mesg = objName + " isn't a '" + clas + "' it's a '"
                  + TestBuilder.typeOf(object) + '"';
            }
        } else {
            // We can just determine what constructor was used. This will
            // not work for inherited constructors.
            var ctor = eval(clas);
            if (object.constructor != ctor)
                mesg = objName + " isn't a '" + clas + "' it's a '"
                  + TestBuilder.typeOf(object) + '"';
        }
    }
    
    var ok;
    if (mesg) {
        ok = TestMore.Test.ok(false, name);
        TestMore.Test.diag('    ' + mesg);
    } else {
        ok = TestMore.Test.ok(true, name);
    }

    return ok;
}

function pass (name) {
    return TestMore.Test.ok(true, name);
}

function fail (name) {
    return TestMore.Test.ok(false, name);
}

function diag () {
    if (!TestMore.ShowDiag) return;
    return TestMore.Test.diag.apply(TestMore.Test, arguments);
}

// Use this instead of use_ok and require_ok.
function loadOk () {
    // XXX What do I do here? Eval?
    // XXX Just always fail for now, to keep people from using it just yet.
    return false;
}

function skip (why, howMany) {
    if (howMany == null) {
        if (!TestBuilder.NoPlan)
            TestBuild.warn("skip() needs to know howMany tests are in the block");
        howMany = 1;
    }
    for (i = 0; i < howMany; i++) {
        TestMore.Test.skip(why);
    }
    // XXX This doesn't work...
    //    eval("break SKIP");
}

function todoSkip (why, howMany) {
    if (howMany == null) {
        if (!TestBuilder.NoPlan)
            TestBuilder.warn("todoSkip() needs to know howMany tests are in the block");
        howMany = 1;
    }

    for (i = 0; i < howMany; i++) {
        TestMore.Test.todoSkip(why);
    }

    // XXX This doesn't work...
    //    eval("break TODO");
}

function isDeeply (it, as, name) {
    if (arguments.length != 2 && arguments.length != 3) {
        TestBuilder.warn(
            'isDeeply() takes two or three args, you gave '
            + arguments.length + "."
        );
    }

    var ok;
    // ^ is the XOR operator.
    if (isRef(it) ^ isRef(as)) {
        // One's a reference, one isn't.
        ok = false;
    } else if (!isRef(it) && !isRef(as)) {
        // Neither is an object.
        ok = TestMore.Test.isEq(it, as, name);
    } else {
        // We have two objects. Do a deep comparison.
        var stack = [], seen = [];
        if ( _deepCheck(it, as, stack, seen)) {
            ok = TestMore.Test.ok(true, name);
        } else {
            ok = TestMore.Test.ok(false, name);
            TestMore.Test.diag(_formatStack(stack));
        }
    }
    return ok;
}

function _deepCheck (e1, e2, stack, seen) {
    var ok = false;
    // Either they're both references or both not.
    var sameRef = !(!isRef(e1) ^ !isRef(e2));
    if (e1 == null && e2 == null) {
        ok = true;
    } else if (e1 != null ^ e2 != null) {
        ok = false;
    } else if (e1 == TestMore.DNE ^ e2 == TestMore.DNE) {
        ok = false;
    } else if (sameRef && e1 == e2) {
        // Handles primitives and any variables that reference the same
        // object, including functions.
        ok = true;
    } else if (isa(e1, 'Array') && isa(e2, 'Array')) {
        ok = _eqArray(e1, e2, stack, seen);
    } else if (typeof e1 == "object" && typeof e2 == "object") {
        ok = _eqAssoc(e1, e2, stack, seen);
    } else {
        // If we get here, they're not the same (function references must
        // always simply rererence the same function).
        stack.push({ vals: [e1, e2] });
        ok = false;
    }
    return ok;
}

function isRef(object) {
    var type = typeof object;
    return type == 'object' || type == 'function';
}

function _formatStack (stack) {
    var variable = '$Foo';
    var didArrow = 0;
    for (var i in stack) {
        var entry = stack[i];
        var type = entry['type'];
        var idx = entry['idx'];
        //        if (type == 'Array') {
            if (!didArrow++)  variable += '.';
            if (/^\d+$/.test(idx)) {
                // Numeric array index.
                variable += '[' + idx + ']';
            } else {
                // Associative array index.
                idx = idx.replace("'", "\\'");
                variable += "['" + idx + "']";
            }
        //        }
    }

    var vals = stack[stack.length-1]['vals'].slice(0, 2);
    var vars = [
        variable.replace('$Foo',     'got'),
        variable.replace('$Foo',     'expected')
    ];

    var out = "Structures begin differing at:\n";
    for (var i in vals) {
        var val = vals[i];
        if (val == null) {
            val = 'undefined';
        } else {
             val == TestMore.DNE ? "Does not exist" : "'" + val + "'";
        }
    }

    out += vars[0] + ' = ' + vals[0] + "\n";
    out += vars[1] + ' = ' + vals[1] + "\n";
    
    return '    ' + out;
}

function eqArray (a1, a2) {
    if (!isa(a1, 'Array') || !isa(a2, 'Array')) {
        TestBuilder.warn("Non-array passed to eqArray()");
        return false;
    }
    return _eqArray(a1, a2, [], []);
}

function _eqArray (a1, a2, stack, seen) {
    // Return if they're the same object.
    if (a1 == a2) return true;

    // JavaScript objects have no unique identifiers, so we have to store
    // references to them all in an array, and then compare the references
    // directly It's slow, but probably won't be much of an issue in practice.
    for (var j in seen) {
        if (seen[j][0] == a1) {
            return seen[j][1] == a2;
        }
    }

    // If we get here, we haven't seen a1 before, so store it with reference
    // to a2.
    seen.push([ a1, a2 ]);

    var ok = true;
    // Only examines enumerable attributes. Only works for numeric arrays!
    // Associative arrays return 0. So call _eqAssoc() for them, instead.
    var max = a1.length > a2.length ? a1.length : a2.length;
    if (max == 0) return _eqAssoc(a1, a2, stack, seen);
    for (var i = 0; i < max; i++) {
        var e1 = i > a1.length - 1 ? TestMore.DNE : a1[i];
        var e2 = i > a2.length - 1 ? TestMore.DNE : a2[i];
        stack.push({ type: 'Array', idx: i, vals: [e1, e2] });
        if (ok = _deepCheck(e1, e2, stack, seen)) {
            stack.pop;
        } else {
            break;
        }
    }
    return ok;
}

function eqHash () {
    return eqAssoc.apply(this, arguments);
}

function eqAssoc (o1, o2) {
    if (typeof o1 != "object" || typeof o2 != "object") {
        TestBuilder.warn("Non-object passed to eqAssoc()");
        return false;
    } else if (   (isa(o1, 'Array') && o1.length > 0)
               || (isa(o2, 'Array') && o2.length > 0))
    {
        TestBuilder.warn("Ordered array passed to eqAssoc()");
        return false;
    }
    return _eqAssoc(o1, o2, [], []);
}

function _eqAssoc (o1, o2, stack, seen) {
    // Return if they're the same object.
    if (o1 == o2) return true;

    // JavaScript objects have no unique identifiers, so we have to store
    // references to them all in an array, and then compare the references
    // directly It's slow, but probably won't be much of an issue in practice.
    for (var j in seen) {
        if (seen[j][0] == o1) {
            return seen[j][1] == o2;
        }
    }

    // If we get here, we haven't seen o1 before, so store it with reference
    // to o2.
    seen.push([ o1, o2 ]);

    // They should be of the same class.

    var ok = true;
    // Only examines enumerable attributes.
    var o1Size = 0; for (var i in o1) o1Size++;
    var o2Size = 0; for (var i in o2) o2Size++;
    var bigger = o1Size > o2Size ? o1 : o2;
    for (var i in bigger) {
        var e1 = o1[i] == undefined ? TestMore.DNE : o1[i];
        var e2 = o2[i] == undefined ? TestMore.DNE : o2[i];
        stack.push({ type: 'Object', idx: i, vals: [e1, e2] });
        if (ok = _deepCheck(e1, e2, stack, seen)) {
            stack.pop;
        } else {
            break;
        }
    }
    return ok;
}

function eqSet (a1, a2) {
    if (a1.length != a2.length) return false;
    return eqArray(a1.slice(0).sort(), a2.slice(0).sort());
}


TestMore.builder = function () { return TestMore.Test; }

function isa (object, clas) {
    return TestBuilder.typeOf(object) == clas;
}