function plan (cmd, arg) {
    return TestBuilder.Test.plan(cmd, arg);
}

function ok (val, desc) {
    return TestBuilder.Test.ok(val, desc);
}
