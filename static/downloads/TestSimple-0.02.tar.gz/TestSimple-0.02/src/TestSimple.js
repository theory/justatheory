// # $Id: Kinetic.pm 1493 2005-04-07 19:20:18Z theory $
function plan (cmd, arg) {
    return TestBuilder.Test.plan(cmd, arg);
}

function ok (val, desc) {
    return TestBuilder.Test.ok(val, desc);
}
